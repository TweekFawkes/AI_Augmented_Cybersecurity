# Vulnerable Web App

This intentionally vulnerable Node.js application is provided for educational purposes. It contains several common security issues that you can practice finding and fixing:

- **Hard‑coded secrets**: The `.env` file contains API keys and passwords and is committed to the repository. The default route also prints the API key.
- **Path traversal**: The `/user?username=...` endpoint reads files from the `data/` directory based on user‑controlled input without validation.
- **Command injection**: The `/exec?cmd=...` endpoint passes user input directly to `child_process.exec()`.
- **Arbitrary code execution**: The `/calc?expr=...` endpoint evaluates user‑supplied JavaScript expressions via `eval()`.
- **Exposed secret file**: `secret_token.txt` is committed and contains sensitive information.

Run the app with `node server.js` and visit `http://localhost:3000` to explore. Use it as a target for security auditing exercises.
