const http = require('http');
const fs = require('fs');
const { exec } = require('child_process');

// Read secrets from .env (insecure: committed to repo)
let env = {};
try {
  const envText = fs.readFileSync('.env', 'utf8');
  envText.split('\n').forEach(line => {
    const [key, value] = line.split('=');
    if (key) env[key.trim()] = value.trim();
  });
} catch (err) {
  console.warn('Could not read .env file');
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (url.pathname === '/user') {
    // Vulnerable path traversal: reads arbitrary files from data folder
    const username = url.searchParams.get('username');
    const filePath = `./data/${username}.json`;
    try {
      const data = fs.readFileSync(filePath, 'utf8');
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(data);
    } catch (err) {
      res.writeHead(404);
      res.end('User not found');
    }
    return;
  }

  if (url.pathname === '/exec') {
    // Dangerous command execution vulnerability
    const cmd = url.searchParams.get('cmd');
    exec(cmd, (error, stdout, stderr) => {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      if (error) {
        res.end(`error: ${error.message}`);
        return;
      }
      if (stderr) {
        res.end(`stderr: ${stderr}`);
        return;
      }
      res.end(stdout);
    });
    return;
  }

  if (url.pathname === '/calc') {
    // Dangerous eval vulnerability
    const expr = url.searchParams.get('expr');
    try {
      const result = eval(expr);
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(`Result: ${result}`);
    } catch (err) {
      res.writeHead(400);
      res.end(`Invalid expression: ${err.message}`);
    }
    return;
  }

  // Default route
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end(`Welcome to the vulnerable web app!\nAPI_KEY=${env.API_KEY}`);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
